package com.example.Spring.Restful.Evaluation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestfulEvaluationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestfulEvaluationApplication.class, args);
	}

}
