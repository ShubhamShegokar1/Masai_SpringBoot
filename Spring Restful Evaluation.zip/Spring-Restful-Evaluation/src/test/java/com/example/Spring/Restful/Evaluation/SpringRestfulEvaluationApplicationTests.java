package com.example.Spring.Restful.Evaluation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestfulEvaluationApplicationTests {

	@Test
	void contextLoads() {
	}

}
